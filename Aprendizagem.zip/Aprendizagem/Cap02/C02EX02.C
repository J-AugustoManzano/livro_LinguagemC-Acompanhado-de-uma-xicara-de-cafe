// C02EX02.C

#include <stdio.h>

int main(void)
{
  char PAUSA;

  printf("Alo, mundo!");

  printf("\n");
  printf("Tecle <Enter> para encerrar... ");
  PAUSA = getchar();

  return 0;
}
