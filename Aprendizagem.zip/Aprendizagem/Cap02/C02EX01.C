// C02EX01.C

#include <stdio.h>

int main(void)
{
  printf("Alo, mundo!");
  return 0;
}
