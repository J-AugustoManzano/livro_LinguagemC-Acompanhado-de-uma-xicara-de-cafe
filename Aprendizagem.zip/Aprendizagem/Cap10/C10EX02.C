// C10EX02.C

float A = 5.5, B = 2.7;
