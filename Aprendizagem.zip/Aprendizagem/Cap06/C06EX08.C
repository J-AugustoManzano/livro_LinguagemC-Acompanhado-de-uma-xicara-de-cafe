// C06EX08.C

#include <stdio.h>
#include <time.h>

int main(void)
{

  char PAUSA;

  time_t TEMPO = time(NULL);

  printf("%s", ctime(&TEMPO));

  printf("\n");
  printf("Tecle <Enter> para encerrar... ");
  PAUSA = getchar();

  return 0;
}
