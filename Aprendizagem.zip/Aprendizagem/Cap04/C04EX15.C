// C04EX15.C

#include <stdio.h>

int main(void)
{

  char PAUSA;

  int N, I, R;

  printf("Entre o valor da tabuada: ");
  scanf("%i", &N);
  while ((getchar() != '\n') && (!EOF));
  printf("\n");

  I = 1;
  loop:
    R = N * I;
    printf("%2i X %2i = %3i\n", N, I, R);
    if (I > 9) goto endloop;
    ++I;
    goto loop;
  endloop:

  printf("\n");
  printf("Tecle <Enter> para encerrar... ");
  PAUSA = getchar();

  return 0;
}
