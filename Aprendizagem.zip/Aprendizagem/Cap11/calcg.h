// calcg.h

int fatorial(int N);
int somatorio(int N);
