// calcm.h 

#ifndef CALCM_H
#define CALCM_H

extern __declspec(dllexport) int fatorial(int N);
extern __declspec(dllexport) int somatorio(int N);

#endif
